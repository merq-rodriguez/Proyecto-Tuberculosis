import { Component, Inject, BadRequestException } from '@nestjs/common';



@Component()
export class PhoneService{
    constructor(
        @Inject('DbConnection') private connection
    ){}

public CreatePhone(
    numero : String,
    idPersona : number
){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'INSERT INTO telefono(numero, fkPersona) VALUES(?,?)',[numero, idPersona],(err, results) => {
                return !err
                    ? resolve({ 'message': 'Telefono registradao' })
                    :  reject(new BadRequestException(err.message))
        })
    })
}



public getPhone( id : number ){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'SELECT * FROM telefono WHERE idTelefono = ? AND estado = 1', id, (err, result) => {
                return !err
                    ? resolve({ result })
                    :  reject(new BadRequestException(err.message))
        })
    })
}

public getAllPhones(idPersona : number){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'SELECT * FROM telefono WHERE fkPersona = ? AND estado = 1', idPersona,(err, result) => {
                return !err
                    ? resolve(result)
                    :  reject(new BadRequestException(err.message))
        })
    })
}




public UpdatePhone(
    idTelefono : number,
    numero : String,
    idPersona : number
){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'UPDATE telefono SET numero = ?, fkPersona = ? WHERE idTelefono = ? AND estado = 1',[numero, idPersona, idTelefono],(err, results) => {
                return !err
                    ? resolve({'message' : 'Telefono actualizado.'})
                    : reject(new BadRequestException(err.message))
            }
        )
    })
}

public DeletePhone(id : number){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'UPDATE telefono SET estado = 0 WHERE idTelefono = ?',id,(err, results) => {
                return !err
                    ? resolve({'message' : 'Se elimino el telefono.'})
                    : reject(new BadRequestException(err.message))
            }
        )
    })
}

}