import { Controller, Get, Delete, Request, Response, Body, Param, HttpStatus, Post } from '@nestjs/common';
import { SymptomService } from './symptom.service';

@Controller('symptom')
export class SymptomController{
    constructor(private symptomService : SymptomService){}

    @Post('/create')
    public async createPatient(
        @Response() res,
        @Request() req,
        @Body('nombre') nombre, 
        @Body('fechainicio') fechainicio,
        @Body('tiposintomas') tiposintomas,
        @Body('idPaciente') idPaciente 
    ){
        const response = await this.symptomService.CreateSymptom(nombre, fechainicio, tiposintomas, idPaciente)
        res.status(HttpStatus.OK).json(response)
    }

    @Get('/All/:idPaciente')
    public async getAllSymptom(
        @Request() req,
        @Response() res,
        @Param('idPaciente') idPaciente
    ){
        const pacientes = await this.symptomService.getAllSymptom(idPaciente)
        res.status(HttpStatus.OK).json(pacientes)
    }

    @Get('/:idSintoma')
    public async getSymptom(
        @Request() req,
        @Response() res,
        @Param('idSintoma') idSintoma
    ){
        const symptom = await this.symptomService.getSymptom(idSintoma)
        res.status(HttpStatus.OK).json(symptom)
    }

    @Get('/:idSintoma')
    public async DeleteSymptom(
        @Request() req,
        @Response() res,
        @Param('idSintoma') idSintoma
    ){
        const symptom = await this.symptomService.DeleteSymptom(idSintoma)
        res.status(HttpStatus.OK).json(symptom)
    }


}