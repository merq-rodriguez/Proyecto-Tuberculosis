import 'dotenv/config';

export const Config = {
  PORT: 4000,
  SECRET: 'clavesecreta',
  DB:{
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'tuberculosis'
  }
}
