import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { DatabaseModule } from './modules/batabase/database.module';
import { ManagePatientModule } from './modules/manage-patient/manage-patient.module';
import { ManagePeopleModule } from './modules/manage-people/manage-people.module';
import { UserModule } from './modules/users/user.module';
import { ManageLocationModule } from './modules/manage-location/location.module';
import { ManagePhysicianModule } from './modules/manage-physicians/manage-physician.module';
import { ManageQuestionaryModule } from './modules/manage-questionaires/questionary-question.module';


@Module({
  controllers: [],
  components: [],
  imports: [DatabaseModule,  
            UserModule,
            ManagePatientModule,
            ManagePeopleModule, 
            ManageLocationModule,
            ManagePhysicianModule,
            ManageQuestionaryModule,
            ManageQuestionaryModule]
})
export class ApplicationModule {}
