import { Module, MiddlewaresConsumer } from '@nestjs/common';
import { PatientController } from './patients/patient.controller';
import { PatientService } from './patients/patient.service';
import { SymptomService } from './symptom/symptom.service';
import { SymptomController } from './symptom/symptom.controller';


@Module({
    controllers: [PatientController, SymptomController],
    components: [PatientService, SymptomService],
    imports: []
})

export class ManagePatientModule{}
