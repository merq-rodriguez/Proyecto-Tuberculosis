import { Component, Inject, BadRequestException } from '@nestjs/common';



@Component()
export class PersonService{
    constructor(
        @Inject('DbConnection') private connection
    ){}

public CreatePerson(
    id : number,
    nombres : String,
    apellidos : String,
    ocupacion : String,
    grupo_poblacional : String,
    fecha_nacimiento : Date,
    lugar_nacimiento : number,
    tipo_documento : number,
    genero : number
){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'CALL ProSavePersona(?,?,?,?,?,?,?,?,?,?)', ['REGISTRAR',id, nombres, apellidos, ocupacion, grupo_poblacional, fecha_nacimiento, lugar_nacimiento, tipo_documento, genero],(err, results) => {
                return !err
                    ? resolve({ 'message': 'Persona registrada' })
                    :  reject(new BadRequestException(err.message))
        })
    })
}



public getPerson( id : number ){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'SELECT * FROM persona WHERE doc_identificacion = ? AND estado = 1', id, (err, result) => {
                return !err
                    ? resolve({ result })
                    :  reject(new BadRequestException(err.message))
        })
    })
}


public getAllPeople(){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'SELECT * FROM persona WHERE estado = 1', (err, result) => {
                return !err
                    ? resolve({ result })
                    :  reject(new BadRequestException(err.message))
        })
    })
}




public UpdatePerson(
    id : number,
    nombres : String,
    apellidos : String,
    ocupacion : String,
    grupo_poblacional : String,
    fecha_nacimiento : Date,
    lugar_nacimiento : number,
    tipo_documento : number,
    genero : number
){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'CALL ProSavePersona(?,?,?,?,?,?,?,?,?,?)', ['ACTUALIZAR',id, nombres, apellidos, ocupacion,grupo_poblacional, fecha_nacimiento, lugar_nacimiento, tipo_documento, genero],(err, results) => {
                return !err
                    ? resolve({'message' : 'Se actualizo la persona correctamente.'})
                    : reject(new BadRequestException(err.message))
            }
        )
    })
}

public DeletePerson(id : number){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'UPDATE persona SET estado = 0 WHERE doc_identificacion = ?',id,(err, results) => {
                return !err
                    ? resolve({'message' : 'Se elimino la persona correctamente.'})
                    : reject(new BadRequestException(err.message))
            }
        )
    })
}

}