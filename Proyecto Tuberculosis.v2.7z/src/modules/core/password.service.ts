import { Component } from '@nestjs/common'
import { HttpException } from '@nestjs/core'
import { db } from '../../config/db.connection'

@Component()
export class PasswordService {


}