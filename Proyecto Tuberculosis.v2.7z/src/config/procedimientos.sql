DELIMITER @
CREATE PROCEDURE ProSavePersona(
    IN _accion VARCHAR(30),
    IN _identificacion INT,
    IN _nombres VARCHAR(255),
    IN _apellidos VARCHAR(255),
    IN _ocupacion VARCHAR(255),
    IN _grupo_poblacional VARCHAR(255),
	IN _fechanacimiento DATE,
	IN _fkLugarnacimiento INT,
	IN _fkTipodocumento INT,
	IN _fkGenero INT
)
BEGIN
    CASE _accion
        WHEN 'REGISTRAR' THEN 
            INSERT INTO persona(doc_identificacion, nombres, apellidos, ocupacion,grupo_poblacional,fechanacimiento, fkLugarnacimiento, fkTipodocumento, fkGenero, estado) 
            VALUES(_identificacion, _nombres, _apellidos, _ocupacion, _grupo_poblacional,_fechanacimiento, _fkLugarnacimiento, _fkTipodocumento, _fkGenero, 1);
        WHEN 'ACTUALIZAR' THEN 
            UPDATE persona 
            SET doc_identificacion = _identificacion, 
            nombres = _nombres,
            apellidos = _apellidos,
            ocupacion = _ocupacion,
            grupo_poblacional  = _grupo_poblacional,
            fechanacimiento = _fechanacimiento,
            fkLugarnacimiento = _fkLugarnacimiento,
            fkTipodocumento = _fkTipodocumento,
            fkGenero = _fkGenero
            WHERE doc_identificacion = _identificacion;
    END CASE;
END@
DELIMITER ;

CALL ProSavePersona('REGISTRAR', 1117534247, 'Pepito', 'Robledo Valencia', 'Lechero','AFRODECENDIENTE', '1994/11/29', 1, 1, 1);

DELIMITER @
CREATE PROCEDURE ProSaveUsuario(
    IN _accion VARCHAR(20),
    IN _username VARCHAR(255),
	IN _email VARCHAR(255),
	IN _password VARCHAR(255),
	IN _fkPersona INT,
	IN _fkRol INT
)
BEGIN
    CASE _accion
    WHEN 'REGISTRAR' THEN 
        INSERT INTO usuario(username, email, password, fkPersona, fkRol, estado) 
        VALUES(_username, _email, _password, _fkPersona, _fkRol, 1);
    when 'ACTUALIZAR' THEN 
        UPDATE usuario 
        SET username = _username,
        email = _email,
        password = _password,
        fkPersona = _fkPersona,
        fkRol = _fkRol
        WHERE fkPersona = _fkPersona;
    END CASE;
END@
DELIMITER ;

CALL ProRegistrarUsuario('REGISTRAR','uchihaxd', 'pepito@gmail.com', '1234', 1117534247, 1);

DELIMITER @
CREATE PROCEDURE ProSavePaciente(
   IN _accion VARCHAR(25),
   IN _estatura FLOAT,
   IN _peso INT,
   IN _talla INT, 
   IN _fkPersona INT,
   IN _fkCondicion_ingreso INT
)
BEGIN
DECLARE imc FLOAT;
SET imc = (select _peso / POW(_estatura,2) ); #Peso por estatura en metros al cuadrado
    CASE _accion
        WHEN 'REGISTRAR' THEN
            INSERT INTO paciente(imc, estatura, peso, talla, fkPersona, fkCondicion_ingreso) 
            VALUES(imc, _estatura, _peso, _talla, _fkPersona, _fkCondicion_ingreso);
        WHEN 'ACTUALIZAR' THEN 
            UPDATE paciente 
            SET estatura = _estatura,
            peso = _peso,
            talla = _talla,
            fkPersona = _fkPersona,
            fkCondicion_ingreso = _fkCondicion_ingreso
            WHERE fkPersona = _fkPersona; 
    END CASE;
END@
DELIMITER ;

CALL ProSavePaciente('ACTUALIZAR',2.5, 70, 900, 1117534247, 1);

DELIMITER @
CREATE PROCEDURE ProRegistrarLugartrabajo(
    _nombre VARCHAR(255),
    _fecha DATE,
	_fkPersona INT,
	_fkLugar INT,
	_prefijo VARCHAR(255),
    _numero VARCHAR(255),
    _sufijo VARCHAR(255),
    _barrio VARCHAR (255)
)
BEGIN
    INSERT INTO direccion (prefijo, numero, sufijo, barrio, fkPersona) 
    VALUES(_prefijo, _numero, _sufijo, _barrio, _fkPersona);
    INSERT INTO lugartrabajo(nombre, fecha,fkPersona, fkLugar, fkDireccion) 
    VALUES (_nombre, _fecha, _fkPersona, _fkLugar, (SELECT last_insert_id()));
END@
DELIMITER ;

CALL  ProRegistrarLugartrabajo('CASINO LAS VEGAS', NOW(), 1117534247, 1, 'CALLE', '1a', '123', 'VIRGINIA CENTRO');

select * from lugartrabajo AS lu 
INNER JOIN direccion AS dir 
ON dir.idDireccion = lu.dkDireccion
WHERE lu.fkPersona = 1083908649;

DELIMITER @
CREATE PROCEDURE ProActualizarLugartrabajo(
    _idDireccion INT,
    _idLugarTrabajo INT,
    _nombre VARCHAR(255),
    _fecha DATE,
	_fkPersona INT,
	_fkLugar INT,
	_prefijo VARCHAR(255),
    _numero VARCHAR(255),
    _sufijo VARCHAR(255),
    _barrio VARCHAR (255)
)
BEGIN
    UPDATE direccion 
    SET prefijo = _prefijo,
        numero = _numero,
        sufijo = _sufijo,
        barrio = _barrio,
        fkPersona = _fkPersona
    WHERE idDireccion = _idDireccion;
    
    UPDATE lugartrabajo 
    SET nombre = _nombre,
        fecha = _fecha,
        fkPersona = _fkPersona,
        fkLugar = _fkLugar
    WHERE idTrabajo = _idLugarTrabajo;
END@
DELIMITER ;

CALL ProActualizarLugartrabajo(3, 1, 'CASINO FARAONES', NOW(), 1117534247, 1, 'CALLE', '1a', '123', 'VIRGINIA CENTRO');



DELIMITER @
CREATE PROCEDURE ProRegistrarResidencia(
	IN _duracion INT,
    IN _fecha DATE, 
    IN _fkLugar INT,
    IN _fkPersona INT,
    IN _prefijo VARCHAR(255),
    IN _numero VARCHAR(255),
    IN _sufijo VARCHAR(255),
    IN _barrio VARCHAR (255)
)
BEGIN
    INSERT INTO direccion (prefijo, numero, sufijo, barrio, fkPersona) 
    VALUES(_prefijo, _numero, _sufijo, _barrio, _fkPersona);
    INSERT INTO lugar_residencia(duracion_meses, fecha, fkLugar, fkDireccion, fkPersona)
    VALUES(_duracion, _fecha, _fkLugar, (SELECT last_insert_id()), _fkPersona);
END@
DELIMITER ;

CALL ProRegistrarResidencia(23, NOW(),1, 1117534247, 'CALLE', '1a', '123', 'VIRGINIA CENTRO');


DELIMITER @
CREATE PROCEDURE ProActualizarResidencia(
    IN _idDireccion INT,
    IN _idResidencia INT,
	IN _duracion INT,
    IN _fecha DATE, 
    IN _fkLugar INT,
    IN _fkPersona INT,
    IN _prefijo VARCHAR(255),
    IN _numero VARCHAR(255),
    IN _sufijo VARCHAR(255),
    IN _barrio VARCHAR (255)
)
BEGIN
     UPDATE direccion 
     SET prefijo = _prefijo,
         numero = _numero,
         sufijo = _sufijo,
         barrio = _barrio,
         fkPersona = _fkPersona
     WHERE idDireccion = _idDireccion;
            
    UPDATE lugar_residencia 
    SET duracion_meses = _duracion,
        fecha = _fecha,
        fkLugar = _fkLugar,
        fkDireccion = _idDireccion,
        fkPersona = _fkPersona
    WHERE idResidencia = _idResidencia;
END@
DELIMITER ;

CALL ProActualizarResidencia(2, 1, 102, NOW(), 1, 1117534247, 'calle','123', '20-02','CENTRO');


DELIMITER @
CREATE PROCEDURE ProRegistrarPregunta(
    IN _nombre_pregunta VARCHAR(255),
    IN _idCuestionario INT
)
BEGIN
    INSERT INTO pregunta(nombre) VALUES(_nombre_pregunta);
    INSERT INTO pregunta_cuestionario (fkPregunta, fkCuestionario) 
    VALUES((SELECT last_insert_id()), _idCuestionario);
END@
DELIMITER ;

