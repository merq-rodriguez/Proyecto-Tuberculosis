import { Controller, Get, Delete, Request, Response, Body, Param, HttpStatus, Post, Put } from '@nestjs/common';
import { PersonService } from './person.service';

@Controller('/people')
export class PersonController{
    constructor(private personService :PersonService){}


    @Post('/create')
    public async CreatePerson(
        @Response() res,
        @Request() req,
        @Body('id') id,
        @Body('nombres') nombres,
        @Body('apellidos') apellidos,
        @Body('ocupacion') ocupacion,
        @Body('grupo_poblacional') grupo_poblacional,
        @Body('fecha_nacimiento') fecha_nacimiento,
        @Body('lugar_nacimiento') lugar_nacimiento,
        @Body('tipo_documento') tipo_documento,
        @Body('genero') genero          
    ){
        let Strfecha = Date.parse(fecha_nacimiento);
        let Dfecha = new Date(Strfecha); 
        //console.log(typeof Dfecha)
        //console.log(id, nombres, apellidos, ocupacion, grupo_poblacional, fecha_nacimiento, lugar_nacimiento,tipo_documento, genero);
        const response = await this.personService.CreatePerson(id, nombres, apellidos, ocupacion,grupo_poblacional, Dfecha, lugar_nacimiento, tipo_documento, genero)
        res.status(HttpStatus.OK).json(response)
    }

    @Put('/update')
    public async UpdatePerson(
        @Response() res,
        @Request() req,
        @Body('id') id,
        @Body('nombres') nombres,
        @Body('apellidos') apellidos,
        @Body('ocupacion') ocupacion,
        @Body('grupo_poblacional') grupo_poblacional,
        @Body('fecha_nacimiento') fecha_nacimiento,
        @Body('lugar_nacimiento') lugar_nacimiento,
        @Body('tipo_documento') tipo_documento,
        @Body('genero') genero          
    ){
        let Strfecha = Date.parse(fecha_nacimiento);
        let Dfecha = new Date(Strfecha);
        const response = await this.personService.UpdatePerson(id, nombres, apellidos, ocupacion,grupo_poblacional, Dfecha, lugar_nacimiento, tipo_documento, genero)
        res.status(HttpStatus.OK).json(response)
    }

    @Get('/All')
    public async getPeople(
        @Request() req,
        @Response() res
    ){
        const people = await this.personService.getAllPeople()
        res.status(HttpStatus.OK).json(people);
    }

    @Delete('/delete/:id')
    public async DeletePerson(
        @Request() req,
        @Response() res,
        @Param('id') id 
    ){
        const person = await this.personService.DeletePerson(id)
        res.status(HttpStatus.OK).json(person);
    }

    @Get('/:id')
    public async getPerson(
        @Request() req,
        @Response() res,
        @Param('id') id 
    ){
        const person = await this.personService.getPerson(id)
        res.status(HttpStatus.OK).json(person);
    }

   
    



}