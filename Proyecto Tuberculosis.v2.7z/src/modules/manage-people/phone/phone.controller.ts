import { Controller, Get, Delete, Request, Response, Body, Param, HttpStatus, Post, Put } from '@nestjs/common';
import { PhoneService } from './phone.service';

@Controller('/phones')
export class PhoneController{
    constructor(private phoneService :PhoneService){}

    @Get('/All/:idPersona')
    public async getAllPhones(
        @Request() req,
        @Response() res,
        @Param('idPersona') idPersona
    ){
        const phones = await this.phoneService.getAllPhones(idPersona)
        res.status(HttpStatus.OK).json(phones);
    }


    @Post('/create')
    public async CreatePhone(
        @Response() res,
        @Request() req,
        @Body('numero')  numero, 
        @Body('idPersona')  idPersona
                
    ){
        console.log(numero)
        const response = await this.phoneService.CreatePhone(numero, idPersona)
        res.status(HttpStatus.OK).json(response)
    }

    @Put('/update')
    public async UpdatePhone(
        @Response() res,
        @Request() req,
        @Body('idTelefono')  idTelefono,         
        @Body('numero')  numero, 
        @Body('idPersona')  idPersona
                
    ){
        console.log(numero)
        const response = await this.phoneService.UpdatePhone(idTelefono, numero, idPersona)
        res.status(HttpStatus.OK).json(response)
    }

   

    @Delete('/delete/:id')
    public async DeletePhone(
        @Request() req,
        @Response() res,
        @Param('id') id 
    ){
        const person = await this.phoneService.DeletePhone(id)
        res.status(HttpStatus.OK).json(person);
    }

    @Get('/getOne/:id')
    public async getPhone(
        @Request() req,
        @Response() res,
        @Param('id') id 
    ){
        const person = await this.phoneService.getPhone(id)
        res.status(HttpStatus.OK).json(person);
    }

   
    



}