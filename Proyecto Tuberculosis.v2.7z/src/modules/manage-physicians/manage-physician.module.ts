import { Module, MiddlewaresConsumer } from '@nestjs/common';
import { PhysicianController } from './physician/physician.controller';
import { PhysicianService } from './physician/physician.service';



@Module({
    controllers: [PhysicianController],
    components: [PhysicianService],
    imports: []
})

export class ManagePhysicianModule{}
