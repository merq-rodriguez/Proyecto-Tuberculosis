import { Component, Inject, BadRequestException } from '@nestjs/common';


@Component()
export class PhysicianService{
    constructor(
        @Inject('DbConnection') private connection
    ){}


public CreatePhysician(idMedico : number, especialidad : String){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'INSERT INTO medico(idMedico, especialidad) VALUES(?,?)',[idMedico, especialidad],(err, results) => {
                return !err
                    ? resolve({ 'message': 'Medico registrado' })
                    :  reject(new BadRequestException(err.message))
        })
    })
}


public UpdatePhysician(idMedico : number, especialidad : String){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'UPDATE medico SET especialidad = ? WHERE idMedico = ? AND estado = 1',[especialidad, idMedico ],(err, results) => {
                return !err
                    ? resolve({ 'message': 'Medico actualizado.' })
                    :  reject(new BadRequestException(err.message))
        })
    })
}


public getPhysician(idMedico : number){
    return new Promise( (resolve, reject) => {
        this.connection.query('SELECT * FROM medico WHERE idMedico = ? AND estado = 1', idMedico,(err, result) => {
                return !err
                    ? resolve(result)
                    :  reject(new BadRequestException(err.message))
        })
    })
}

public getAllPhysician(){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'SELECT * FROM medico WHERE estado = 1',  (err, result) => {
                return !err
                    ? resolve({ result })
                    :  reject(new BadRequestException(err.message))
        })
    })
}

public DeletePhysician(id : number){
    console.log(id)
    return new Promise( (resolve, reject) => {
        this.connection.query(
            'UPDATE medico SET estado = 0 WHERE idMedico = ?',id,(err, results) => {
                return !err
                    ? resolve({'message' : 'Medico eliminado.'})
                    : reject(new BadRequestException(err.message))
            }
        )
    })
}

}