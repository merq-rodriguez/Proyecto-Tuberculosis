import { Controller, Get, Delete, Request, Response, Body, Param, HttpStatus, Post, Put } from '@nestjs/common';
import { PhysicianService } from './physician.service';


@Controller('/physicians')
export class PhysicianController{
    constructor(private physicianService : PhysicianService){}


    @Post('/create')
    public async CreatePhysician(
        @Request() req,
        @Response() res,
        @Body('especialidad') especialidad,
        @Body('idMedico') idMedico
    ){
        const response = await this.physicianService.CreatePhysician(idMedico, especialidad)
        res.status(HttpStatus.OK).json(response)
    }

    @Put('/update')
    public async UpdatePhysician(
        @Request() req,
        @Response() res,
        @Body('idMedico') idMedico,
        @Body('especialidad') especialidad
    ){
        const response= await this.physicianService.UpdatePhysician(idMedico, especialidad)
        res.status(HttpStatus.OK).json(response)
    }

    @Get('/getOne/:idMedico')
    public async getMedicine(
        @Request() req,
        @Response() res,
        @Param('idMedico') idMedico
    ){
        const physician = await this.physicianService.getPhysician(idMedico)
        res.status(HttpStatus.OK).json(physician)
    }

    @Get('/All')
    public async getAllPhysician(
        @Request() req,
        @Response() res,
    ){
        const response = await this.physicianService.getAllPhysician()
        res.status(HttpStatus.OK).json(response)
    }

    @Delete('/delete/:idMedico')
    public async DeleteResidencePlace(
        @Request() req,
        @Response() res,
        @Param('idMedico') idMedico
    ){
        const response = await this.physicianService.DeletePhysician(idMedico)
        res.status(HttpStatus.OK).json(response)
    }

}