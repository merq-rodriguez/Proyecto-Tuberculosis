CREATE DATABASE tuberculosis;
USE tuberculosis;

CREATE TABLE IF NOT EXISTS departamento(
	idDepartamento INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1 
);

CREATE TABLE IF NOT EXISTS municipio(
	idMunicipio INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	fkDepartamento INT,
	estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(fkDepartamento) REFERENCES departamento(idDepartamento)
);

CREATE TABLE IF NOT EXISTS rol(
	idRol INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	nombre VARCHAR(255),
	descripcion TEXT,
	estado CHAR(1) DEFAULT 1
);

INSERT INTO rol VALUES(1, 'ADMINISTRADOR', 'Se encarga de administrar todo el sistema', 1);
INSERT INTO rol VALUES(2, 'PACIENTE', 'Es un paciente del proceso', 1);
CREATE TABLE IF NOT EXISTS condicion_ingreso(
	idIngreso INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	descripcion TEXT,
	estado CHAR(1) DEFAULT 1
);

INSERT INTO condicion_ingreso VALUES(1, 'Paciente nuevo', 'Paciente que nunca ha sido tratado por tuberculosis o que ha recibido medicamentos anti tuberculoso por menos de un mes.',1);
INSERT INTO condicion_ingreso VALUES(2, 'Tras recaída', 'paciente que ha sido previamente tratado por tuberculosis, fue declarado curado o tratamiento terminado al final de su último ciclo de tratamiento, y ahora es diagnosticado con un episodio recurrente de tuberculosis (ya sea una verdadera recaída o un nuevo episodio de tuberculosis causado por reinfección).',1);
INSERT INTO condicion_ingreso VALUES(3, 'Tras fracaso', 'paciente previamente tratado por tuberculosis, cuyo tratamiento fracasó.',1);
INSERT INTO condicion_ingreso VALUES(4, 'Recuperado tras pérdida de seguimiento', 'paciente que ha sido tratado previa-mente por tuberculosis y declarado pérdida al seguimiento al final de su tratamiento más reciente.',1);
INSERT INTO condicion_ingreso VALUES(5, 'Otros pacientes previamente tratados', 'son aquellos que han sido previamente tratados por tuberculosis, pero cuyo resultado después del tratamiento más reciente es desconocido o indocumentado.',1);



CREATE TABLE IF NOT EXISTS genero(
	idGenero INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1
);

INSERT INTO genero VALUES (1, 'MASCULINO', 1);
INSERT INTO genero VALUES (2, 'FEMENINO', 1);


CREATE TABLE IF NOT EXISTS tipodocumento(
	idTipodoc INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1
);

INSERT INTO tipodocumento VALUES (1, 'CEDULA DE CIUDADANIA', 1);
INSERT INTO tipodocumento VALUES (2, 'TARGETA DE IDENTIDAD', 1);
INSERT INTO tipodocumento VALUES (3, 'PASAPORTE', 1);


CREATE TABLE IF NOT EXISTS persona(
	doc_identificacion INT PRIMARY KEY NOT NULL,
	nombres VARCHAR(255),
	apellidos VARCHAR(255),
	grupo_poblacional VARCHAR(255),
	ocupacion VARCHAR(255),
	fechanacimiento DATE,
	fkLugarnacimiento INT,
	fkTipodocumento INT,
	fkGenero INT,
	estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(fkLugarnacimiento) REFERENCES municipio(idMunicipio),
    FOREIGN KEY(fkTipodocumento) REFERENCES tipodocumento(idTipodoc),
    FOREIGN KEY(fkGenero) REFERENCES genero(idGenero)
);

CREATE TABLE IF NOT EXISTS lugar_residencia(
	idResidencia INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	duracion_meses INT,
	fecha DATE,
	fkLugar INT,
	fkDireccion INT,
	fkPersona INT,
	estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(fkLugar) REFERENCES municipio(idMunicipio),
    FOREIGN KEY(fkPersona) REFERENCES persona(doc_identificacion),
	FOREIGN KEY(fkDireccion) REFERENCES direccion(idDireccion)
);


CREATE TABLE IF NOT EXISTS paciente(
	idPaciente INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	imc FLOAT,
	estatura FLOAT,
	peso INT,
	talla INT, 
	fkPersona INT UNIQUE,
	fkCondicion_ingreso INT,
	estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(fkPersona) REFERENCES persona(doc_identificacion),
    FOREIGN KEY(fkCondicion_ingreso) REFERENCES condicion_ingreso(idIngreso)	
);

CREATE TABLE IF NOT EXISTS direccion(
	idDireccion INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    prefijo VARCHAR(20),
    numero VARCHAR(50),
	sufijo VARCHAR(50),
	barrio VARCHAR(255),
	fkPersona INT,
	estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(fkPersona) REFERENCES persona(doc_identificacion)
);

CREATE TABLE IF NOT EXISTS lugartrabajo(
	idtrabajo INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	fecha DATE,
	fkPersona INT,
	fkLugar INT,
	fkDireccion INT,
	estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(fkPersona) REFERENCES persona(doc_identificacion),
    FOREIGN KEY(fkLugar) REFERENCES municipio(idMunicipio),
    FOREIGN KEY(fkDireccion) REFERENCES direccion(idDireccion)	
);

CREATE TABLE IF NOT EXISTS localizacion(
	idLocalizacion INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	latitud VARCHAR(255),
	longitud VARCHAR(255),
	fkDireccion INT,
	estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(fkDireccion) REFERENCES direccion(idDireccion)
);


CREATE TABLE IF NOT EXISTS telefono(
    idTelefono INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    numero VARCHAR(10),
    fkPersona INT,
    estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(fkPersona) REFERENCES persona(doc_identificacion)
); 




CREATE TABLE IF NOT EXISTS usuario(
	idUsuario INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	username VARCHAR(255) UNIQUE,
	email VARCHAR(255) UNIQUE,
	password VARCHAR(255),
	fkPersona INT UNIQUE,
	fkRol INT,
	estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(fkRol) REFERENCES rol(idRol),
    FOREIGN KEY(fkPersona) REFERENCES persona(doc_identificacion) 
);


CREATE TABLE IF NOT EXISTS gestacion(
	idGestacion INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	semanas INT,
	fecha_inicio DATE UNIQUE,
	fkPersona INT,
	estado char(1) DEFAULT 1,
    FOREIGN KEY(fkPersona) REFERENCES persona(doc_identificacion)    
);
CREATE TABLE IF NOT EXISTS cuestionario(
	idCuestionario INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1
);

INSERT INTO cuestionario(nombre) VALUES('Informacion Adicional de persona');
INSERT INTO cuestionario(nombre) VALUES('Datos de laboratorio');


CREATE TABLE IF NOT EXISTS pregunta(
	idPregunta INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1
);


#POner un tipo a las preguntas
#Tipos de pregunta: cerrada, abierta.
INSERT INTO pregunta(nombre) VALUES ('¿Tiene cicatriz de vacuna BCG?');
INSERT INTO pregunta(nombre) VALUES ('¿Tiene vacuna BCG registrada en carné?');


#Informacion Adicion (NOMBRE DEL CUSTIONARIO)

INSERT INTO pregunta(nombre) VALUES ('¿Es trabajador de la salud?');
INSERT INTO pregunta(nombre) VALUES ('¿Sí en el punto anterior marco sí escriba la ocupación en salud.');
INSERT INTO pregunta(nombre) VALUES ('¿Presenta diagnóstico previo de VIH?');
INSERT INTO pregunta(nombre) VALUES ('¿Se realizó asesoría pre-test de VIH?');
INSERT INTO pregunta(nombre) VALUES ('¿Se realizó prueba para diagnóstico de VIH?');
INSERT INTO pregunta(nombre) VALUES ('¿Hay coinfección tuberculosis - VIH/sida?');
INSERT INTO pregunta(nombre) VALUES ('¿Terapia preventiva con Trimetropin sulfa/cotrimoxazol?');
INSERT INTO pregunta(nombre) VALUES ('¿Recibe tratamiento antiretroviral?');
INSERT INTO pregunta(nombre) VALUES ('¿Inicio tratamiento?');

#Datos de laboratorio (NOMBRE DEL CUESTIONARIO)
#Hay que tener en cuenta que muchas de estas preguntas se solucionan
#Con las demas tablas.
INSERT INTO pregunta(nombre) VALUES ('¿Se utilizó prueba molecular para la confirmación del caso?');
INSERT INTO pregunta(nombre) VALUES ('¿Baciloscopia?');
INSERT INTO pregunta(nombre) VALUES ('¿Cultivo?');
INSERT INTO pregunta(nombre) VALUES ('¿Histopatología?');
INSERT INTO pregunta(nombre) VALUES ('¿Cuadro clínico?');
INSERT INTO pregunta(nombre) VALUES ('¿Nexo epidemiológico?');
INSERT INTO pregunta(nombre) VALUES ('¿Radiológico?');
INSERT INTO pregunta(nombre) VALUES ('¿Adenosina deaminasa (ADA)?');
INSERT INTO pregunta(nombre) VALUES ('¿Tuberculina?');





CREATE TABLE IF NOT EXISTS pregunta_cuestionario(
	fkPregunta INT,
    fkCuestionario INT,
	respuesta varchar(255), 
	estado CHAR(1) DEFAULT 1,
	PRIMARY KEY(fkPregunta, fkCuestionario),
    FOREIGN KEY (fkPregunta) REFERENCES pregunta(idPregunta),
    FOREIGN KEY (fkCuestionario) REFERENCES cuestionario(idCuestionario)   
);



CREATE TABLE IF NOT EXISTS cuestionario_persona(
	fkCuestionario INT,
	fkPersona INT,
	estado CHAR(1) DEFAULT 1,
	FOREIGN KEY(fkCuestionario) REFERENCES cuestionario(idCuestionario),
	FOREIGN KEY(fkPersona) REFERENCES persona(doc_identificacion)
);

CREATE TABLE IF NOT EXISTS medico(
	idMedico INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	especialidad VARCHAR(255),
	estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(idMedico) REFERENCES usuario(idUsuario)
);



CREATE TABLE IF NOT EXISTS nivelexposicion(
	idNivelexpocicion INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	descripcion TEXT,
	estado CHAR(1) DEFAULT 1
);

INSERT INTO nivelexposicion(nombre, descripcion) VALUES('NIVEL I', 'Convivientes habituales del paciente tuberculoso.');
INSERT INTO nivelexposicion(nombre, descripcion) VALUES('NIVEL II', 'Contacto frecuente.');
INSERT INTO nivelexposicion(nombre, descripcion) VALUES('NIVEL III', 'Contacto ocasional con un enfermo bacilífero.');





CREATE TABLE IF NOT EXISTS tiporelacion(
	idTiporelacion INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1
);

INSERT INTO tiporelacion VALUES(1, 'RELACION DE AMISTAD', 1);
INSERT INTO tiporelacion VALUES(2, 'RELACION AMOROSA', 1);
INSERT INTO tiporelacion VALUES(3, 'RELACION DE TRABAJO', 1);
INSERT INTO tiporelacion VALUES(4, 'RELACION DEPORTIVA', 1);
INSERT INTO tiporelacion VALUES(5, 'RELACION ACADEMICA', 1);




CREATE TABLE IF NOT EXISTS cadenacontacto( #Personas que han tenido contacto con el paciente
	idContacto INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	estadosalud VARCHAR(255),
	duracioncontacto TIME,
	fechacontacto DATE,
	contexto VARCHAR(255),
	fkPersona INT,
	fkLugarcontacto INT,
	fkDireccioncontacto INT,
	fkTiporelacion INT,
	fkNivelexposicion INT,
	estado CHAR(1) DEFAULT 1,
    FOREIGN KEY(fkPersona) REFERENCES persona(doc_identificacion),    
    FOREIGN KEY(fkLugarcontacto) REFERENCES municipio(idMunicipio),    
    FOREIGN KEY(fkDireccioncontacto) REFERENCES direccion(idDireccion),    
    FOREIGN KEY(fkTiporelacion) REFERENCES tiporelacion(idTiporelacion),    
    FOREIGN KEY(fkNivelexposicion) REFERENCES nivelexposicion(idNivelexpocicion)
);

CREATE TABLE IF NOT EXISTS paciente_cadenacontacto(
	fkPaciente INT,
	fkCadenacontacto INT,
	estado CHAR(1),
	PRIMARY key(fkPaciente, fkCadenacontacto),
    FOREIGN KEY(fkPaciente) REFERENCES paciente(idPaciente),    
    FOREIGN KEY(fkCadenacontacto) REFERENCES cadenacontacto(idContacto)    
);

CREATE TABLE IF NOT EXISTS sintoma(
	idSintoma INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	fechainicio DATE,
	tiposintomas VARCHAR(255), #Tener en cuenta la duracion.
	fkPaciente INT,
	estado CHAR(1) DEFAULT 1,
	FOREIGN KEY (fkPaciente) REFERENCES paciente(idPaciente)
);

CREATE TABLE IF NOT EXISTS nivel_laboratorio(
	idNivellaboratorio INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	descripcion TEXT,
	estado CHAR(1) DEFAULT 1
);


INSERT INTO nivel_laboratorio VALUES(1, 'LABORATORIOS CLINICOS NIVEL I', 'Realizan bacilos copia, algunos inoculan muestras de esputo y remiten a otro nivel para el proceso de incubación.', 1);
INSERT INTO nivel_laboratorio VALUES(2, 'LABORATORIOS CLINICOS NIVEL II', 'Realizan baciloscopia, algunos inoculan la muestra de esputo y remiten a otro nivel para el proceso de incubación, aquellos que tienen área de microbiología hacen el proceso completo del cultivo.', 1);
INSERT INTO nivel_laboratorio VALUES(3, 'LABORATORIOS CLINICOS NIVEL III', 'Realizan baciloscopia y cultivo de muestras pulmonares y extrapulmonares, aquellos con capacidad e infraestructura realizan pruebas moleculares', 1);




CREATE TABLE IF NOT EXISTS tratamiento(
	codigo INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1)
);

CREATE TABLE IF NOT EXISTS tratamiento_paciente(
	idTrataPaciente INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	fkTratamiento INT,
	fkPaciente INT,
	estado CHAR(1),
	FOREIGN KEY (fkTratamiento) REFERENCES tratamiento(codigo),
	FOREIGN KEY (fkPaciente) REFERENCES paciente(idPaciente)
);
















CREATE TABLE IF NOT EXISTS laboratorio(
	idLaboratorio INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	fecha DATE,
	fkNivel_laboratorio INT,
	estado CHAR(1) DEFAULT 1,
	FOREIGN KEY(fkNivel_laboratorio) REFERENCES nivel_laboratorio(idNivellaboratorio)
);

CREATE TABLE IF NOT EXISTS detalle_laboratorio(
	fkLaboratorio INT,
	fkPaciente INT,
	estado CHAR(1),
	PRIMARY KEY(fkLaboratorio, fkPaciente),
	FOREIGN KEY(fkLaboratorio) REFERENCES laboratorio(idLaboratorio),
	FOREIGN KEY(fkPaciente) REFERENCES paciente(idPaciente)
);


CREATE TABLE IF NOT EXISTS medicamento(  
	idMedicamento INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	descripcion TEXT,
	estado CHAR(1) DEFAULT 1
);

CREATE TABLE IF NOT EXISTS fase(
    idFase INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(255),
    fkFase INT,
    estado CHAR(1) DEFAULT 1
);

ALTER TABLE fase ADD FOREIGN KEY (fkFase)REFERENCES fase(idFase);

CREATE TABLE IF NOT EXISTS dosis_medicamento(  
	idDosis INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	cantidad INT, 
	fecha DATE,
	fkPaciente INT,
	fkMedicamento INT,
	fkFase INT,
	estado CHAR(1) DEFAULT 1,
	FOREIGN KEY (fkPaciente) REFERENCES paciente(idPaciente),
	FOREIGN KEY (fkMedicamento) REFERENCES medicamento(idMedicamento),
	FOREIGN KEY (fkFase) REFERENCES fase(idFase)
);



CREATE TABLE IF NOT EXISTS diagnostico_tratamiento(
	idDiagnostico INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	fecha DATE,
	fkPaciente INT,
	fkMedico INT,
	fkTuberculosis INT,
	estado CHAR(1) DEFAULT 1,
);

CREATE TABLE IF NOT EXISTS tuberculosis(
	idTuberculosis INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(100),
	descripcion TEXT
);

INSERT INTO tuberculosis(nombre, tipo, descripcion) VALUES('TUBERCULOSIS PULMONAR', 'lorem');
INSERT INTO tuberculosis(nombre, tipo, descripcion) VALUES('TUBERCULOSIS EXTRAPULMONAR', 'lorem');

CREATE TABLE IF NOT EXISTS tipo_tuberculosis(
	idTube_tipo INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(100),
	descripcion TEXT
);

INSERT INTO tipo_tuberculosis(nombre,  descripcion) VALUES('TUBERCULOSIS RESISTENTE', 'lorem');
INSERT INTO tipo_tuberculosis(nombre,  descripcion) VALUES('TUBERCULOSIS SENSIBLE', 'lorem');

CREATE TABLE IF NOT EXISTS diagnostico_laboratorio(
	idDetalle_labo INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	fkPaciente INT,
	fkTuberculosis INT,
	fkTipo_tuberculosis INT,
	fkLaboratorio INT,
	observaciones TEXT,
	estado CHAR(1),
	FOREIGN KEY (fkPaciente) REFERENCES paciente(idPaciente),
	FOREIGN KEY (fkTuberculosis) REFERENCES tuberculosis(idTuberculosis),
	FOREIGN KEY (fkTipo_tuberculosis) REFERENCES tipo_tuberculosis(idTube_tipo),
	FOREIGN KEY (fkLaboratorio) REFERENCES laboratorio(idLaboratorio)	
);



CREATE TABLE IF NOT EXISTS detalle_extrapulmonar(
	idQuimioprofilaxis INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	fkLocaizacion_extra INT
	descripcion TEXT,
	estado CHAR(1) DEFAULT 1
);





#===================================================================================
#			PRUEBAS LABORATORIO
#===================================================================================

CREATE TABLE IF NOT EXISTS prueba_sensibilidadfarmaco(  
	idPruebasencibilidad INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	fecha DATE,
	fkLaboratorio INT,
	estado CHAR(1) DEFAULT 1
);


CREATE TABLE IF NOT EXISTS basiloscopia(  
	idBasiloscopia INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	resultado ENUM('1-','2+', '3++', '4+++'),
	fecha DATE,
	fkLaboratorio INT,
	estado CHAR(1) DEFAULT 1
);

CREATE TABLE IF NOT EXISTS resultado_reportecultivo(
	idReportecultivo INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1	
);

INSERT INTO resultado_reportecultivo VALUES(1, 'Positivo entre 1-20 colonias BAAR', 1);
INSERT INTO resultado_reportecultivo VALUES(2, '(+) 21 a 100 colonias BAAR', 1);
INSERT INTO resultado_reportecultivo VALUES(3, '(++) Más de 100 colonias BAAR', 1);
INSERT INTO resultado_reportecultivo VALUES(4, '(+++) Colonias BAAR confluentes', 1);
INSERT INTO resultado_reportecultivo VALUES(5, 'Cultivo negativo', 1);
INSERT INTO resultado_reportecultivo VALUES(6, 'Contaminado', 1);
INSERT INTO resultado_reportecultivo VALUES(7, 'En proceso', 1);



CREATE TABLE IF NOT EXISTS cultivo(  
	idCultivo INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	fecha DATE,
	fkLaboratorio INT,
	estado CHAR(1) DEFAULT 1,
	FOREIGN KEY(fkLaboratorio) REFERENCES laboratorio(idLaboratorio)
);


CREATE TABLE IF NOT EXISTS especie(
	idEspecie INT INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	fkCultivo INT,
	estado CHAR(1) DEFAULT 1,
	FOREIGN KEY(fkCultivo) REFERENCES cultivo(idCultivo)
);

CREATE TABLE IF NOT EXISTS localizacion_extrapulmonar(
	idLocalizacion_extrapul INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1
);

INSERT INTO localizacion_extrapulmonar VALUES (1, 'PLEURAL', 1);
INSERT INTO localizacion_extrapulmonar VALUES (2, 'MININGEA', 1);
INSERT INTO localizacion_extrapulmonar VALUES (3, 'PERITONEAL', 1);
INSERT INTO localizacion_extrapulmonar VALUES (4, 'GANGLIONAR', 1);
INSERT INTO localizacion_extrapulmonar VALUES (5, 'RENAL', 1);
INSERT INTO localizacion_extrapulmonar VALUES (6, 'INTESTINAL', 1);
INSERT INTO localizacion_extrapulmonar VALUES (7, 'OSTEOARTICULAR', 1);
INSERT INTO localizacion_extrapulmonar VALUES (8, 'GENITOURINARIA', 1);
INSERT INTO localizacion_extrapulmonar VALUES (9, 'PERICARDICA', 1);
INSERT INTO localizacion_extrapulmonar VALUES (10, 'CUTANEA', 1);
INSERT INTO localizacion_extrapulmonar VALUES (11, 'OTRO', 1);









CREATE TABLE IF NOT EXISTS tipoprueba_molecular(  
	idTipo_pruebamolecular INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1
);

INSERT INTO tipoprueba_molecular VALUES(1, 'Sist. cerrado PCR tiempo real', 'Amplificación e hibridación de sondas en línea', 'Otro',1);
INSERT INTO tipoprueba_molecular VALUES(1, 'Amplificación e hibridación de sondas en línea', 'Otro',1);
INSERT INTO tipoprueba_molecular VALUES(1, 'Otro', 1);



CREATE TABLE IF NOT EXISTS prueba_molecular(  
	idCultivo INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	fecha DATE,
	fkTipo_pruebamolecular INT,
	fkLaboratorio INT,
	estado CHAR(1) DEFAULT 1,
	FOREIGN KEY(fkLaboratorio) REFERENCES laboratorio(idLaboratorio),
	FOREIGN KEY(fkTipo_pruebamolecular) REFERENCES tipoprueba_molecular(idTipo_pruebamolecular)
);


CREATE TABLE IF NOT EXISTS biopsia(
	idBiopsia INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1
);




CREATE TABLE IF NOT EXISTS muestra(
	idMuestra INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255),
	estado CHAR(1) DEFAULT 1
);

#Tipos de muestras:
#(+) Para muestras de orina, líquido seminal, flujo menstrual, materia fecal y
#sangre, serán recolectadas según indicaciones del laboratorio
#(+) Pueden ser (líquidos: cefalorraquídeo, pleural, pericárdico, ascítico y sinovial, biopsias)

CREATE TABLE IF NOT EXISTS conservacionmuestra(  
	idtransporte INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	duracionhoras INT,
	temperatura INT,#grados Centigrados
	fkMuestra INT,
	estado CHAR(1) DEFAULT 1,
	FOREIGN KEY(fkMuestra) REFERENCES  muestra(idMuestra)
);


#Contenedor para las muestras
CREATE TABLE IF NOT EXISTS recipiente(  
	idRecipiente INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	dimencion VARCHAR(20),
	solucion VARCHAR(255),
	tapa VARCHAR(255), #CIERRE HERMETICO
	estado CHAR(1) DEFAULT 1
);


CREATE TABLE IF NOT EXISTS transporte(  
	idtransporte INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	fkRecipiente VARCHAR(255),
	fecha DATE,
	fkMuestra INT,
	fkLaboratorio INT,
	estado CHAR(1) DEFAULT 1
);





















CREATE TABLE IF NOT EXISTS tratamiento(
	idTratamiento INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	fechainicio DATE,
	fkTipotratamiento INT,
	
	estado CHAR(1) DEFAULT 1
);

CREATE TABLE IF NOT EXISTS diagnosticotratamiento(
	idHistorialtratamiento INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	fechadiagnostico DATE,
	estadoactual VARCHAR(255),
	fkTratamiento INT,
	estado CHAR(1) DEFAULT 1
);









