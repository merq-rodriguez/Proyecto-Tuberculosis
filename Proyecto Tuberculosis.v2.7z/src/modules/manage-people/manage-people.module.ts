import { Module, MiddlewaresConsumer } from '@nestjs/common';
import { GestationController } from '../manage-people/gestation/gestation.controller';
import { GestationService } from './gestation/gestation.service';
import { PersonController } from './people/person.controller';
import { PersonService } from './people/person.service';
import { PhoneService } from './phone/phone.service';
import { PhoneController } from './phone/phone.controller';


@Module({
    controllers: [GestationController, PersonController, PhoneController],
    components: [GestationService, PersonService, PhoneService],
    imports: []
})

export class ManagePeopleModule{}
