import { Component, Inject, BadRequestException } from '@nestjs/common';


@Component()
export class MedicineService{
    constructor(
        @Inject('DbConnection') private connection
    ){}


public CreateMedicine(

){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            '',(err, results) => {
                return !err
                    ? resolve({ 'message': 'Medicamento registrado' })
                    :  reject(new BadRequestException(err.message))
        })
    })
}


public UpdateMedicine(

){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            '',(err, results) => {
                return !err
                    ? resolve({ 'message': 'Medicamento actualizado.' })
                    :  reject(new BadRequestException(err.message))
        })
    })
}


public getMedicine(idMedicamento : number){
    return new Promise( (resolve, reject) => {
        this.connection.query('', idMedicamento,(err, result) => {
                return !err
                    ? resolve(result)
                    :  reject(new BadRequestException(err.message))
        })
    })
}

public getAllMedicines(){
    return new Promise( (resolve, reject) => {
        this.connection.query(
            '',  (err, result) => {
                return !err
                    ? resolve({ result })
                    :  reject(new BadRequestException(err.message))
        })
    })
}

public DeleteMedicine(id : number){
    console.log(id)
    return new Promise( (resolve, reject) => {
        this.connection.query(
            '',id,(err, results) => {
                return !err
                    ? resolve({'message' : 'Medicamento eliminado.'})
                    : reject(new BadRequestException(err.message))
            }
        )
    })
}

}